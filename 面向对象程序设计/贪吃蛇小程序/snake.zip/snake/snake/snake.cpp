#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <chrono>
#include <unordered_map>
#include <fstream>
#include <string>
using namespace std;
using namespace chrono;
string name;
class Snake {
private:
    int score;
    int length;
    int num[40][40];
    int fruit_num;
    int max_score;
    int move_x;
    int move_y;
    int health_points;
    int direction;
    int flag[40][40];
    bool h = false;
    bool wall[40][40];
    bool deter;
    unordered_map<int, int> map_x;
    unordered_map<int, int> map_y;
public:
    Snake() {
        history();
        init();
    }
    void init() {
        for (int i = 0; i < 40; i++) {
            for (int j = 0; j < 40; j++) {
                num[i][j] = 0;
                flag[i][j] = -1;
                wall[i][j] = false;
                if (j == 39 || j == 0 || i == 0 || i == 39) {
                    wall[i][j] = true;
                }
            }
        }
        num[19][19] = 2;
        num[20][19] = 1;
        map_x[1] = 20;
        map_y[1] = 19;
        map_x[2] = 19;
        map_y[2] = 19;
        score = 0;
        length = 2;
        fruit_num = 0;
        move_x = 0;
        move_y = 0;
        health_points = -1;
        direction = -1;
        deter = true;
    }
    void draw(int x) {
        for (int i = 0; i < 40; i++) {
            fillrectangle(10, 10 + 12 * i, 20, 20 + 12 * i);
            fillrectangle(10 + 12 * i, 10, 20 + 12 * i, 20);
            fillrectangle(478, 10 + 12 * i, 488, 20 + 12 * i);
            fillrectangle(10 + 12 * i, 478, 20 + 12 * i, 488);
        }
        setfillcolor(CYAN);
        fillcircle(15 + 12 * 20, 15 + 12 * 19, 5);
        fillcircle(15 + 12 * 19, 15 + 12 * 19, 3);
        fruit();
        setfillcolor(BROWN);
        solidrectangle(500, 10, 654, 15);
        solidrectangle(500, 10, 505, 210);
        solidrectangle(649, 10, 654, 215);
        solidrectangle(500, 210, 654, 215);
        setfillcolor(WHITE);
        solidrectangle(505, 15, 512, 210);
        solidrectangle(505, 15, 649, 22);
        solidrectangle(642, 15, 649, 210);
        solidrectangle(505, 203, 649, 210);
        solidrectangle(505, 109, 649, 116);
        LOGFONT f;
        gettextstyle(&f);						// ��ȡ��ǰ��������
        f.lfHeight = 28;						// ��������߶�Ϊ 28
        _tcscpy(f.lfFaceName, _T("����"));		// ��������Ϊ�����塱(�߰汾 VC �Ƽ�ʹ�� _tcscpy_s ����)
        f.lfQuality = ANTIALIASED_QUALITY;		// �������Ч��Ϊ�����  
        settextstyle(&f);						// ����������ʽ
        settextcolor(YELLOW);
        outtextxy(516, 120, _T("���ֵ÷�:"));
        outtextxy(516, 26, _T("��ʷ���:"));
        outtextxy(90, 510, _T("������"));
        outtextxy(330, 510, _T("������"));
        if (x == 3) {
            outtextxy(510, 250, _T("Length:"));
            outtextxy(610, 250, _T("2"));
            outtextxy(500, 300, _T("HP:"));
            IMAGE img;
            loadimage(&img, _T("HP.png"), 30, 30);
            putimage(535, 300, &img);
            putimage(560, 300, &img);
            putimage(585, 300, &img);
            putimage(610, 300, &img);
            putimage(635, 300, &img);
        }
        else {
            outtextxy(510, 270, _T("Length:"));
            outtextxy(610, 270, _T("2"));
        }
        outtextxy(510, 350, _T("Time:00:00"));
        f.lfHeight = 20;
        settextstyle(&f);
        settextcolor(RED);
        outtextxy(510, 392, _T("��Q��������Ϸ"));
        outtextxy(500, 430, _T("���ո����ͣ��Ϸ"));
        f.lfHeight = 48;
        settextstyle(&f);
        settextcolor(YELLOW);
        outtextxy(526, 152, _T("0"));
        outtextxy(553, 152, _T("0"));
        outtextxy(580, 152, _T("0"));
        outtextxy(607, 152, _T("0"));
        outtextxy(526, 58, _T("0"));
        outtextxy(553, 58, _T("0"));
        outtextxy(580, 58, _T("0"));
        outtextxy(607, 58, _T("0"));
        if (max_score < 100) {
            TCHAR s[5];
            _stprintf(s, _T("%d"), max_score / 10);
            outtextxy(580, 58, s);
        }
        else if (max_score < 1000) {
            TCHAR s_[5];
            _stprintf(s_, _T("%d"), max_score % 100 / 10);
            outtextxy(580, 58, s_);
            TCHAR s[5];
            _stprintf(s, _T("%d"), max_score / 100);
            outtextxy(553, 58, s);
        }
        else {
            TCHAR s_[5];
            _stprintf(s_, _T("%d"), max_score % 1000 % 100 / 10);
            outtextxy(580, 58, s_);
            TCHAR s[5];
            _stprintf(s, _T("%d"), max_score % 1000 / 100);
            outtextxy(553, 58, s);
            TCHAR _s[5];
            _stprintf(_s, _T("%d"), max_score / 1000);
            outtextxy(526, 58, _s);
        }
    }
    void fruit() {
        IMAGE img;
        loadimage(&img, _T("apple.jpg"), 10, 10);
        srand(static_cast<unsigned int>(time(nullptr)));
        int new_num = rand() % 5 + 1;
        fruit_num += new_num;
        for (int i = 0; i < new_num; i++) {
            while (1) {
                int x = rand() % 38 + 1;
                int y = rand() % 38 + 1;
                if (flag[x][y] == -1 && !num[x][y]) {
                    flag[x][y] = 0;
                    putimage(10 + 12 * x, 10 + 12 * y, &img);
                    break;
                }
            }
        }
        int bomb = rand() % 3;
        if (bomb == 0) {
            IMAGE bomb_img;
            loadimage(&bomb_img, _T("bomb.png"), 10, 10);
            while (1) {
                int bomb_x = rand() % 38 + 1;
                int bomb_y = rand() % 38 + 1;
                if (flag[bomb_x][bomb_y] == -1 && !num[bomb_x][bomb_y]) {
                    flag[bomb_x][bomb_y] = 2;
                    putimage(10 + 12 * bomb_x, 10 + 12 * bomb_y, &bomb_img);
                    break;
                }
            }
        }
        int orange = rand() % 2;
        if (orange == 0) {
            fruit_num++;
            IMAGE orange_img;
            loadimage(&orange_img, _T("orange.png"), 10, 10);
            while (1) {
                int orange_x = rand() % 38 + 1;
                int orange_y = rand() % 38 + 1;
                if (flag[orange_x][orange_y] == -1 && !num[orange_x][orange_y]) {
                    flag[orange_x][orange_y] = 1;
                    putimage(10 + 12 * orange_x, 10 + 12 * orange_y, &orange_img);
                    break;
                }
            }
        }
    }
    void input(int x) {
        if (x == 3) {
            health_points = 5;
        }
        auto start = high_resolution_clock::now();
        int second = 0;
        while (deter) {
            auto current = high_resolution_clock::now();
            auto duration_m = duration_cast<minutes>(current - start);
            auto duration = duration_cast<seconds>(current - start);
            if (duration.count() < 60) {
                second = (int)duration.count();
                int du_s = (int)duration.count();
                LOGFONT f;
                gettextstyle(&f);
                f.lfHeight = 28;
                settextstyle(&f);
                settextcolor(YELLOW);
                TCHAR s[5];
                _stprintf(s, _T("%d"), du_s);
                if (du_s < 10) {
                    outtextxy(636, 350, s);
                }
                else {
                    outtextxy(622, 350, s);
                }
            }
            else {
                LOGFONT f;
                gettextstyle(&f);
                f.lfHeight = 28;
                settextstyle(&f);
                settextcolor(YELLOW);
                second = (int)duration.count();
                int d_s = (int)duration.count() % 60;
                int d_m = (int)duration.count() / 60;
                TCHAR s[5];
                _stprintf(s, _T("%d"), d_s);
                if (d_s < 10) {
                    outtextxy(622, 350, _T("0"));
                    outtextxy(636, 350, s);
                }
                else {
                    outtextxy(622, 350, s);
                }
                TCHAR _s[5];
                _stprintf(_s, _T("%d"), d_m);
                if (d_m < 10) {
                    outtextxy(593, 350, _s);
                }
                else {
                    outtextxy(580, 350, _s);
                }
            }
            bool fl = false;
            if (_kbhit()) {
                fl = true;
                char key = _getch();
                if ((((move_x == 0 && move_y == -1) || direction == 0) && (key == 's' || key == 'S')) ||
                    (((move_x == 0 && move_y == 1) || direction == 1) && (key == 'w' || key == 'W')) ||
                    (((move_x == -1 && move_y == 0) || direction == 2) && (key == 'd' || key == 'D')) ||
                    (((move_x == 1 && move_y == 0) || direction == 3) && (key == 'a' || key == 'A')) ||
                    (!h && (key == 'a' || key == 'A'))) {
                }
                else {
                    switch (key) {
                        case 'w':
                            move_x = 0;
                            move_y = -1;
                            break;
                        case 's':
                            move_x = 0;
                            move_y = 1;
                            break;
                        case 'a':
                            move_x = -1;
                            move_y = 0;
                            break;
                        case 'd':
                            move_x = 1;
                            move_y = 0;
                            break;
                        case 'q':
                            deter = false;
                            break;
                        case 'W':
                            move_x = 0;
                            move_y = -1;
                            break;
                        case 'S':
                            move_x = 0;
                            move_y = 1;
                            break;
                        case 'A':
                            move_x = -1;
                            move_y = 0;
                            break;
                        case 'D':
                            move_x = 1;
                            move_y = 0;
                            break;
                        case 'Q':
                            deter = false;
                            break;
                        case 32:
                            move_x = 0;
                            move_y = 0;
                            break;
                    }
                }
            }
            if (move_x || move_y) {
                move(move_x, move_y, x);
                int head_x = map_x.find(1)->second + move_x;
                if (head_x < 20) {
                    Sleep(50);
                }
                else {
                    Sleep(100);
                }
            }
        }
        LOGFONT f;
        gettextstyle(&f);
        f.lfHeight = 28;
        settextstyle(&f);
        settextcolor(RED);
        outtextxy(515, 460, _T("Game Over!"));
        ofstream file("history.txt", ios::app);
        if (file.is_open()) {
            if (x == 1) {
                file << "�汾�����Ű� �û�����" << name << " �÷֣�" << score << " ��ʱ��" << second << "s" << endl;
            }
            else if (x == 2) {
                file << "�汾�����װ� �û�����" << name << " �÷֣�" << score << " ��ʱ��" << second << "s" << endl;
            }
            else if (x == 3) {
                file << "�汾���߼��� �û�����" << name << " �÷֣�" << score << " ��ʱ��" << second << "s" << endl;
            }
            file.close();
        }
    }
    void move(int x, int y, int _x) {
        h = true;
        direction = -1;
        auto it_x = map_x.find(length), it_y = map_y.find(length);
        num[it_x->second][it_y->second] = 0;
        setfillcolor(BLACK);
        solidrectangle(10 + 12 * it_x->second, 10 + 12 * it_y->second, 20 + 12 * it_x->second, 20 + 12 * it_y->second);
        int tail_x = map_x.find(length - 1)->second, tail_y = map_y.find(length - 1)->second;
        solidrectangle(10 + 12 * tail_x, 10 + 12 * tail_y, 20 + 12 * tail_x, 20 + 12 * tail_y);
        setfillcolor(CYAN);
        fillcircle(15 + 12 * tail_x, 15 + 12 * tail_y, 3);
        map_x[length] = tail_x;
        map_y[length] = tail_y;
        int head_x = map_x.find(1)->second + x, head_y = map_y.find(1)->second + y;
        setfillcolor(BLACK);
        solidrectangle(10 + 12 * map_x.find(1)->second, 10 + 12 * map_y.find(1)->second, 20 + 12 * map_x.find(1)->second, 20 + 12 * map_y.find(1)->second);
        setfillcolor(CYAN);
        solidcircle(15 + 12 * map_x.find(1)->second, 15 + 12 * map_y.find(1)->second, 5);
        map_x[1] = head_x;
        map_y[1] = head_y;
        num[head_x][head_y] = 1;
        fillcircle(15 + 12 * head_x, 15 + 12 * head_y, 5);
        for (int i = 1; i < length - 1; i++) {
            num[map_x.find(length - i)->second][map_y.find(length - i)->second]++;
            if (i == length - 2) {
                map_x[length - i] = map_x.find(length - i - 1)->second - x;
                map_y[length - i] = map_y.find(length - i - 1)->second - y;
            }
            else {
                map_x[length - i] = map_x.find(length - i - 1)->second;
                map_y[length - i] = map_y.find(length - i - 1)->second;
            }
        }
        if (flag[head_x][head_y] == 0) {
            flag[head_x][head_y] = -1;
            eat(x, y, head_x, head_y);
            LOGFONT f;
            gettextstyle(&f);
            f.lfHeight = 28;
            settextstyle(&f);
            settextcolor(YELLOW);
            TCHAR s[5];
            _stprintf(s, _T("%d"), length);
            if (_x == 3) {
                outtextxy(610, 250, s);
            }
            else {
                outtextxy(610, 270, s);
            }
            score += 10;
            if (score > max_score) {
                if (score < 100) {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score / 10);
                    outtextxy(580, 58, s);
                }
                else if (score < 1000) {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s_[5];
                    _stprintf(s_, _T("%d"), score % 100 / 10);
                    outtextxy(580, 58, s_);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score / 100);
                    outtextxy(553, 58, s);
                }
                else {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s_[5];
                    _stprintf(s_, _T("%d"), score % 1000 % 100 / 10);
                    outtextxy(580, 58, s_);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score % 1000 / 100);
                    outtextxy(553, 58, s);
                    TCHAR _s[5];
                    _stprintf(_s, _T("%d"), score / 1000);
                    outtextxy(526, 58, _s);
                }
            }
            if (score < 100) {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score / 10);
                outtextxy(580, 152, s);
            }
            else if (score < 1000) {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s_[5];
                _stprintf(s_, _T("%d"), score % 100 / 10);
                outtextxy(580, 152, s_);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score / 100);
                outtextxy(553, 152, s);
            }
            else {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s_[5];
                _stprintf(s_, _T("%d"), score % 1000 % 100 / 10);
                outtextxy(580, 152, s_);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score % 1000 / 100);
                outtextxy(553, 152, s);
                TCHAR _s[5];
                _stprintf(_s, _T("%d"), score / 1000);
                outtextxy(526, 152, _s);
            }
        }
        else if (flag[head_x][head_y] == 1) {
            flag[head_x][head_y] = -1;
            eat(x, y, head_x, head_y);
            LOGFONT f;
            gettextstyle(&f);
            f.lfHeight = 28;
            settextstyle(&f);
            settextcolor(YELLOW);
            TCHAR s[5];
            _stprintf(s, _T("%d"), length);
            if (_x == 3) {
                outtextxy(610, 250, s);
            }
            else {
                outtextxy(610, 270, s);
            }
            score += 100;
            if (score > max_score) {
                if (score < 100) {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score / 10);
                    outtextxy(580, 58, s);
                }
                else if (score < 1000) {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s_[5];
                    _stprintf(s_, _T("%d"), score % 100 / 10);
                    outtextxy(580, 58, s_);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score / 100);
                    outtextxy(553, 58, s);
                }
                else {
                    f.lfHeight = 48;
                    settextstyle(&f);
                    TCHAR s_[5];
                    _stprintf(s_, _T("%d"), score % 1000 % 100 / 10);
                    outtextxy(580, 58, s_);
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), score % 1000 / 100);
                    outtextxy(553, 58, s);
                    TCHAR _s[5];
                    _stprintf(_s, _T("%d"), score / 1000);
                    outtextxy(526, 58, _s);
                }
            }
            if (score < 100) {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score / 10);
                outtextxy(580, 152, s);
            }
            else if (score < 1000) {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s_[5];
                _stprintf(s_, _T("%d"), score % 100 / 10);
                outtextxy(580, 152, s_);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score / 100);
                outtextxy(553, 152, s);
            }
            else {
                f.lfHeight = 48;
                settextstyle(&f);
                TCHAR s_[5];
                _stprintf(s_, _T("%d"), score % 1000 % 100 / 10);
                outtextxy(580, 152, s_);
                TCHAR s[5];
                _stprintf(s, _T("%d"), score % 1000 / 100);
                outtextxy(553, 152, s);
                TCHAR _s[5];
                _stprintf(_s, _T("%d"), score / 1000);
                outtextxy(526, 152, _s);
            }
            if (_x == 3 && health_points <= 5) {
                IMAGE HP_img;
                loadimage(&HP_img, _T("HP.png"), 30, 30);
                putimage(535 + 25 * health_points, 300, &HP_img);
                health_points++;
            }
        }
        else if (flag[head_x][head_y] == 2) {
            deter = false;
        }
        if (num[head_x][head_y] > 1 || wall[head_x][head_y]) {
            if (_x == 1) {
                deter = false;
            }
            else if (_x == 2) {
                for (int i = 0; i < 40; i++) {
                    for (int j = 0; j < 40; j++) {
                        if (num[i][j]) {
                            setfillcolor(BLACK);
                            solidrectangle(10 + 12 * i, 10 + 12 * j, 20 + 12 * i, 20 + 12 * j);
                            setfillcolor(WHITE);
                            fillrectangle(10 + 12 * i, 10 + 12 * j, 20 + 12 * i, 20 + 12 * j);
                            wall[i][j] = true;
                            num[i][j] = 0;
                        }
                    }
                }
                for (int i = 1; i <= length; i++) {
                    map_x.erase(i);
                    map_y.erase(i);
                }
                length = 2;
                move_x = 0;
                move_y = 0;
                fruit();
                LOGFONT f;
                gettextstyle(&f);
                f.lfHeight = 28;
                settextstyle(&f);
                settextcolor(YELLOW);
                outtextxy(610, 270, _T("   "));
                TCHAR s[5];
                _stprintf(s, _T("%d"), length);
                outtextxy(610, 270, s);
                int cou = 0;
                while (1) {
                    cou++;
                    head_x = rand() % 38 + 1;
                    head_y = rand() % 38 + 1;
                    int a = rand() % 4;
                    switch (a) {
                        case 0:
                            tail_x = head_x;
                            tail_y = head_y + 1;
                            break;
                        case 1:
                            tail_x = head_x;
                            tail_y = head_y - 1;
                            break;
                        case 2:
                            tail_x = head_x + 1;
                            tail_y = head_y;
                            break;
                        case 3:
                            tail_x = head_x - 1;
                            tail_y = head_y;
                            break;
                    }
                    if (!wall[head_x][head_y] && !wall[tail_x][tail_y]) {
                        num[head_x][head_y] = 1;
                        num[tail_x][tail_y] = 2;
                        map_x[1] = head_x;
                        map_y[1] = head_y;
                        map_x[2] = tail_x;
                        map_y[2] = tail_y;
                        setfillcolor(CYAN);
                        fillcircle(15 + 12 * head_x, 15 + 12 * head_y, 5);
                        fillcircle(15 + 12 * tail_x, 15 + 12 * tail_y, 3);
                        break;
                    }
                    if (cou > 100) {
                        deter = false;
                        break;
                    }
                }
            }
            else if (_x == 3) {
                health_points--;
                setfillcolor(BLACK);
                solidrectangle(535 + 25 * health_points, 300, 560 + 25 * health_points, 350);
                if (!health_points) {
                    deter = false;
                }
                else {
                    for (int i = 0; i < 40; i++) {
                        for (int j = 0; j < 40; j++) {
                            if (num[i][j]) {
                                setfillcolor(BLACK);
                                solidrectangle(10 + 12 * i, 10 + 12 * j, 20 + 12 * i, 20 + 12 * j);
                                if (!wall[i][j]) {
                                    IMAGE img;
                                    loadimage(&img, _T("apple.jpg"), 10, 10);
                                    fruit_num++;
                                    putimage(10 + 12 * i, 10 + 12 * j, &img);
                                    flag[i][j] = 0;
                                }
                                else {
                                    setfillcolor(WHITE);
                                    fillrectangle(10 + 12 * i, 10 + 12 * j, 20 + 12 * i, 20 + 12 * j);
                                }
                                num[i][j] = 0;
                            }
                        }
                    }
                    for (int i = 1; i <= length; i++) {
                        map_x.erase(i);
                        map_y.erase(i);
                    }
                    length = 2;
                    move_x = 0;
                    move_y = 0;
                    fruit();
                    LOGFONT f;
                    gettextstyle(&f);
                    f.lfHeight = 28;
                    settextstyle(&f);
                    settextcolor(YELLOW);
                    outtextxy(610, 250, _T("   "));
                    TCHAR s[5];
                    _stprintf(s, _T("%d"), length);
                    outtextxy(610, 250, s);
                    int cou = 0;
                    while (1) {
                        cou++;
                        head_x = rand() % 38 + 1;
                        head_y = rand() % 38 + 1;
                        direction = rand() % 4;
                        switch (direction) {
                            case 0:
                                tail_x = head_x;
                                tail_y = head_y + 1;
                                break;
                            case 1:
                                tail_x = head_x;
                                tail_y = head_y - 1;
                                break;
                            case 2:
                                tail_x = head_x + 1;
                                tail_y = head_y;
                                break;
                            case 3:
                                tail_x = head_x - 1;
                                tail_y = head_y;
                                break;
                        }
                        if (!wall[head_x][head_y] && !wall[tail_x][tail_y]) {
                            num[head_x][head_y] = 1;
                            num[tail_x][tail_y] = 2;
                            map_x[1] = head_x;
                            map_y[1] = head_y;
                            map_x[2] = tail_x;
                            map_y[2] = tail_y;
                            setfillcolor(CYAN);
                            fillcircle(15 + 12 * head_x, 15 + 12 * head_y, 5);
                            fillcircle(15 + 12 * tail_x, 15 + 12 * tail_y, 3);
                            break;
                        }
                        if (cou > 100) {
                            deter = false;
                            break;
                        }
                    }
                }
            }
        }
    }
    void eat(int x, int y, int head_x, int head_y) {
        auto it_x = map_x.find(length), it_y = map_y.find(length);
        setfillcolor(CYAN);
        solidcircle(15 + 12 * it_x->second, 15 + 12 * it_y->second, 5);
        auto i_x = map_x.find(length - 1), i_y = map_y.find(length - 1);
        if (it_x->second == i_x->second) {
            int tail_x = it_x->second;
            int tail_y = 2 * it_y->second - i_y->second;
            fillcircle(15 + 12 * tail_x, 15 + 12 * tail_y, 3);
            map_x[length + 1] = tail_x;
            map_y[length + 1] = tail_y;
            num[tail_x][tail_y] = length + 1;
        }
        else {
            int tail_x = 2 * it_x->second - i_x->second;
            int tail_y = it_y->second;
            fillcircle(15 + 12 * tail_x, 15 + 12 * tail_y, 3);
            map_x[length + 1] = tail_x;
            map_y[length + 1] = tail_y;
            num[tail_x][tail_y] = length + 1;
        }
        fruit_num--;
        length++;
        if (!fruit_num) {
            fruit();
        }
    }
    void history() {
        ifstream file("history.txt");
        if (file.is_open()) {
            string line;
            while (getline(file, line)) {
                if (line.find("�÷֣�") != string::npos) {
                    size_t pos = line.find("�÷֣�");
                    int current = stoi(line.substr(pos + 6));
                    max_score = max(max_score, current);
                }
            }
            file.close();
        }
        else {
            max_score = 0;
        }
    }
};
void menu() {
    cout << "--------------------------------------------" << endl;
    cout << "A.���Ű�̰����" << endl;
    cout << "B.���װ�̰����" << endl;
    cout << "C.�߼���̰����" << endl;
    cout << "D.�鿴��ʷ��¼" << endl;
    cout << "Q.�˳�" << endl;
    cout << "--------------------------------------------" << endl;
    cout << "[��ѡ��:] ";
}
void A() {
    initgraph(666, 550);
    Snake snake_A;
    snake_A.draw(1);
    snake_A.input(1);
    Sleep(2000);
}
void B() {
    initgraph(666, 550);
    Snake snake_B;
    snake_B.draw(2);
    snake_B.input(2);
    Sleep(2000);
}
void C() {
    initgraph(666, 550);
    Snake snake_C;
    snake_C.draw(3);
    snake_C.input(3);
    Sleep(2000);
}
void D() {
    ifstream file("history.txt");
    if (!file.is_open()) {
        cout << "������ʷ��¼" << endl;
        exit(1);
    }
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
    cout << "�Ƿ�Ҫ����ʷ��¼����ɾ��(1��ʾ�ǣ�0��ʾ��)��";
    int n;
    cin >> n;
    if (n == 1) {
        cout << "ɾ����¼�밴1���޸��û����밴2�������û����밴3���˳��밴0��";
        int nu;
        cin >> nu;
        if (nu == 1) {
            cout << "������Ҫɾ���ļ�¼�����У�";
            int l;
            cin >> l;
            ifstream file("history.txt");
            vector<string> lines;
            string line;
            while (getline(file, line)) {
                lines.push_back(line);
            }
            file.close();
            int count = 1;
            ofstream out("history.txt");
            for (const string& save : lines) {
                if (count != l) {
                    out << save << '\n';
                }
                count++;
            }
            out.close();
            cout << "ɾ����ɣ��������" << endl;
        }
        else if (nu == 2) {
            string x;
            getline(cin, x);
            cout << "������Ҫ�޸ĵ��û�����";
            string fin;
            getline(cin, fin);
            cout << "�������޸ĺ���û�����";
            string _fin;
            getline(cin, _fin);
            bool fi = false;
            ifstream file("history.txt");
            vector<string> lines;
            string line;
            while (getline(file, line)) {
                if (line.find(fin) != string::npos) {
                    fi = true;
                    size_t pos = line.find(fin);
                    line.replace(pos, fin.length(), _fin);
                }
                lines.push_back(line);
            }
            file.close();
            ofstream out("history.txt");
            for (const string& save : lines) {
                out << save << '\n';
            }
            out.close();
            if (!fi) {
                cout << "δ��ѯ�����û���" << endl;
            }
            else {
                cout << "�û����޸ĳɹ�" << endl;
            }
        }
        else if (nu == 3) {
            string x;
            getline(cin, x);
            cout << "������Ҫ���ҵ��û�����";
            string fin;
            getline(cin, fin);
            ifstream file("history.txt");
            string line;
            bool fi = false;
            while (getline(file, line)) {
                if (line.find(fin) != string::npos) {
                    fi = true;
                    cout << line << endl;
                }
            }
            file.close();
            if (!fi) {
                cout << "δ��ѯ�����û���" << endl;
            }
        }
    }
}
int main() {
    int n = 0;
    char str;
    menu();
    while (1) {
        str = _getch();
        if (str == 81 || str == 113) {
            break;
        }
        if (str > 96 && str < 101) {
            n = str - 96;
            cout << str << endl;
            break;
        }
        if (str > 64 && str < 69) {
            n = str - 64;
            cout << str << endl;
            break;
        }
    }
    if (n == 0) {
        if (str == 113) {
            cout << "q";
        }
        else {
            cout << "Q";
        }
    }
    else if (n == 1) {
        cout << "����������û�����";
        getline(cin, name);
        A();
    }
    else if (n == 2) {
        cout << "����������û�����";
        getline(cin, name);
        B();
    }
    else if (n == 3) {
        cout << "����������û�����";
        getline(cin, name);
        C();
    }
    else if (n == 4) {
        D();
    }
    return 0;
}