#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <string>
#include "PicReader.h"
using namespace std;
class jpeg {
private:
    int	width;// ͼ�����
    int height;// ͼ��߶�
    unsigned char* rgb;// RGB ��������
    unsigned char y_table[64];// ����������
    unsigned char cbcr_table[64];// ɫ��������
    // ����������
    const unsigned char luminance[64] =
    {
        16,  11,  10,  16,  24,  40,  51,  61,
        12,  12,  14,  19,  26,  58,  60,  55,
        14,  13,  16,  24,  40,  57,  69,  56,
        14,  17,  22,  29,  51,  87,  80,  62,
        18,  22,  37,  56,  68, 109, 103,  77,
        24,  35,  55,  64,  81, 104, 113,  92,
        49,  64,  78,  87, 103, 121, 120, 101,
        72,  92,  95,  98, 112, 100, 103,  99
    };
    // ɫ��������
    const unsigned char chrominance[64] =
    {
        17,  18,  24,  47,  99,  99,  99,  99,
        18,  21,  26,  66,  99,  99,  99,  99,
        24,  26,  56,  99,  99,  99,  99,  99,
        47,  66,  99,  99,  99,  99,  99,  99,
        99,  99,  99,  99,  99,  99,  99,  99,
        99,  99,  99,  99,  99,  99,  99,  99,
        99,  99,  99,  99,  99,  99,  99,  99,
        99,  99,  99,  99,  99,  99,  99,  99
    };
    // zigzagɨ��˳���
    const char zigzag[64] =
    {
         0, 1, 5, 6,14,15,27,28,
         2, 4, 7,13,16,26,29,42,
         3, 8,12,17,25,30,41,43,
         9,11,18,24,31,40,44,53,
        10,19,23,32,39,45,52,54,
        20,22,33,38,46,51,55,60,
        21,34,37,47,50,56,59,61,
        35,36,48,49,57,58,62,63
    };
    // ��׼ֱ�����ȹ����������
    const char DC_luminance_NRcode[16] = { 0, 0, 7, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0 };
    const unsigned char DC_luminance_value[12] = { 4, 5, 3, 2, 6, 1, 0, 7, 8, 9, 10, 11 };
    // ��׼ֱ��ɫ�ȹ����������
    const char DC_chrominance_NRcode[16] = { 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0 };
    const unsigned char DC_chrominance_value[12] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
    // ��׼�������ȹ����������
    const char AC_luminance_NRcode[16] = { 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d };
    const unsigned char AC_luminance_value[162] =
    {
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12,
        0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07,
        0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08,
        0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0,
        0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16,
        0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
        0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49,
        0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
        0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
        0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79,
        0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
        0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98,
        0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
        0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6,
        0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5,
        0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4,
        0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
        0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea,
        0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
        0xf9, 0xfa
    };
    // ��׼����ɫ�ȹ����������
    const char AC_chrominance_NRcode[16] = { 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77 };
    const unsigned char AC_chrominance_value[162] =
    {
        0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21,
        0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71,
        0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91,
        0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0,
        0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16, 0x24, 0x34,
        0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
        0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38,
        0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
        0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
        0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68,
        0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
        0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
        0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96,
        0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5,
        0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4,
        0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3,
        0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2,
        0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
        0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9,
        0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
        0xf9, 0xfa
    };
    struct bit {
        int length;// ����λ��
        int value;// ����ֵ
    };
    bit y_DC_huffman[12]; // ����DC��������
    bit y_AC_huffman[256];// ����AC��������
    bit cbcr_DC_huffman[12];// ɫ��DC��������
    bit cbcr_AC_huffman[256];// ɫ��AC��������
    void init(int quality);
    void init_huffman(void);
    void compute_huffman(const char* code, const unsigned char* std, bit* _huffman);
    void convert(const unsigned char* _rgb, char* data_y, char* data_cb, char* data_cr);
    void FDC(const char* channel, short* fdc, const unsigned char* quant);
    void huffman(const short* DU, short& prevDC, const bit* HTDC, const bit* HTAC, bit* output, int& count);
    bit get(int value);
    void write_head(FILE* file);
    void write_string(const bit* bs, int count, int& byte, int& bytepos, FILE* file);
    void write_word(unsigned short value, FILE* file);
    void write_byte(unsigned char value, FILE* file);
    void write(const void* p, int byteSize, FILE* file);
public:
    jpeg();
    ~jpeg();
    void change(const BYTE* data, const UINT x, const UINT y);
    void encode(const char* outfile, int quality);
};
jpeg::jpeg() : width(0), height(0), rgb(0) {
    //��ʼ����̬����
    init_huffman();
}
jpeg::~jpeg() {}
void jpeg::change(const BYTE* data, const UINT x, const UINT y) {
    int size = x * y * 3;
    unsigned char* buffer = new(nothrow)unsigned char[size];
    if (buffer == NULL) {
        cout << "�ڴ����ʧ��" << endl;
        exit(1);
    }
    for (DWORD i = 0; i < x * y * 3; i += 3) {
        buffer[i] = data[i / 3 * 4];
        buffer[i + 1] = data[i / 3 * 4 + 1];
        buffer[i + 2] = data[i / 3 * 4 + 2];
    }
    rgb = buffer;
    width = x;
    height = y;
}
void jpeg::encode(const char* outfile, int quality) {
    FILE* file = fopen(outfile, "wb");
    if (file == 0) {
        cout << "�ļ���ʧ��" << endl;
        exit(1);
    }
    init(quality); //��ʼ��������
    write_head(file); //д�ļ�ͷ
    short Y = 0, Cb = 0, Cr = 0;
    int byte = 0, byte_pos = 7;
    for (int y = 0; y < height; y += 8) {
        for (int x = 0; x < width; x += 8) {
            char data_y[64], data_cb[64], data_cr[64];
            short quant_y[64], quant_cb[64], quant_cr[64];
            //ת����ɫ�ռ�, rgb -> (data_y, data_cb, data_cr), [-128,128]
            unsigned char* rgbBuffer = rgb + y * width * 3 + x * 3;
            convert(rgbBuffer, data_y, data_cb, data_cr);
            bit output[128];
            int count;
            //Yͨ��ѹ��(data_y -> quant_y)
            FDC(data_y, quant_y, y_table);
            huffman(quant_y, Y, y_DC_huffman, y_AC_huffman, output, count);
            write_string(output, count, byte, byte_pos, file);
            //Cbͨ��ѹ��(data_cb -> quant_cb)
            FDC(data_cb, quant_cb, cbcr_table);
            huffman(quant_cb, Cb, cbcr_DC_huffman, cbcr_AC_huffman, output, count);
            write_string(output, count, byte, byte_pos, file);
            //Crͨ��ѹ��(data_cr -> quant_cr)
            FDC(data_cr, quant_cr, cbcr_table);
            huffman(quant_cr, Cr, cbcr_DC_huffman, cbcr_AC_huffman, output, count);
            write_string(output, count, byte, byte_pos, file);
        }
    }
    //���ʣ������
    if (byte_pos != 7) {
        write_byte(byte, file);
    }
    write_word(0xFFD9, file); //д��ͼ��������   
    fclose(file);
}
void jpeg::init(int quality) {
    // ����quality��ȡֵ��Χ��(1, 99)
    if (quality <= 0) {
        quality = 1;
    }
    if (quality >= 100) {
        quality = 99;
    }
    // ����quality��ʼ�����Ⱥ�ɫ�ȵ�������
    for (int i = 0; i < 64; i++) {
        // ��ʼ������������
        int temp = ((int)(luminance[i] * quality + 50) / 100);
        if (temp <= 0) {
            temp = 1;
        }
        if (temp > 0xFF) {
            temp = 0xFF;
        }
        y_table[zigzag[i]] = (unsigned char)temp;
        // ��ʼ��ɫ��������
        temp = ((int)(chrominance[i] * quality + 50) / 100);
        if (temp <= 0) {
            temp = 1;
        }
        if (temp > 0xFF) {
            temp = 0xFF;
        }
        cbcr_table[zigzag[i]] = (unsigned char)temp;
    }
}
void jpeg::convert(const unsigned char* _rgb, char* data_y, char* data_cb, char* data_cr) {
    // ת��RGB��ɫ�ռ䵽YCbCr��ɫ�ռ�
    for (int y = 0; y < 8; y++) {
        const unsigned char* p = _rgb + y * width * 3;
        for (int x = 0; x < 8; x++) {
            unsigned char R = *p++;
            unsigned char G = *p++;
            unsigned char B = *p++;
            data_y[y * 8 + x] = (char)(0.29871 * R + 0.58661 * G + 0.11448 * B - 128);
            data_cb[y * 8 + x] = (char)(-0.16874 * R - 0.33126 * G + 0.50000 * B);
            data_cr[y * 8 + x] = (char)(0.50000 * R - 0.41869 * G - 0.08131 * B);
        }
    }
}
void jpeg::FDC(const char* channel, short* fdc, const unsigned char* quant) {
    const float PI = 3.1415926f;
    for (int v = 0; v < 8; v++) {
        for (int u = 0; u < 8; u++) {
            float _u = (float)((u == 0) ? 1 / sqrtf(8.0) : 0.5);
            float _v = (float)((v == 0) ? 1 / sqrtf(8.0) : 0.5);
            float temp = 0;
            for (int x = 0; x < 8; x++) {
                for (int y = 0; y < 8; y++) {
                    float data = channel[y * 8 + x];
                    data *= cosf((2 * x + 1) * u * PI / 16);
                    data *= cosf((2 * y + 1) * v * PI / 16);
                    temp += data;
                }
            }
            int index = zigzag[v * 8 + u];
            //����
            temp *= _u * _v / quant[index];
            fdc[index] = (short)((short)(temp + 16384.5) - 16384);
        }
    }
}
void jpeg::huffman(const short* DU, short& prevDC, const bit* HTDC, const bit* HTAC, bit* output, int& count) {
    bit EOB = HTAC[0x00];
    bit SIXTEEN_ZEROS = HTAC[0xF0];
    int index = 0;
    // ����DC����
    int dc = (int)(DU[0] - prevDC);
    prevDC = DU[0];
    if (dc == 0) {
        output[index++] = HTDC[0];
    }
    else {
        bit bs = get(dc);
        output[index++] = HTDC[bs.length];
        output[index++] = bs;
    }
    // ����AC����
    int end = 63;
    while ((end > 0) && (DU[end] == 0)) {
        end--;
    }
    for (int i = 1; i <= end; i++) {
        int start = i;
        while ((DU[i] == 0) && (i <= end)) i++;
        int zero = i - start;
        if (zero >= 16) {
            for (int j = 1; j <= zero / 16; j++)
                output[index++] = SIXTEEN_ZEROS;
            zero = zero % 16;
        }
        bit bs = get(DU[i]);
        output[index++] = HTAC[(zero << 4) | bs.length];
        output[index++] = bs;
    }
    if (end != 63) {
        output[index++] = EOB;
    }
    count = index;
}
void jpeg::init_huffman(void) {
    // ��ʼ������DC��������
    memset(&y_DC_huffman, 0, sizeof(y_DC_huffman));
    compute_huffman(DC_luminance_NRcode, DC_luminance_value, y_DC_huffman);
    // ��ʼ������AC��������
    memset(&y_AC_huffman, 0, sizeof(y_AC_huffman));
    compute_huffman(AC_luminance_NRcode, AC_luminance_value, y_AC_huffman);
    // ��ʼ��ɫ��DC��������
    memset(&cbcr_DC_huffman, 0, sizeof(cbcr_DC_huffman));
    compute_huffman(DC_chrominance_NRcode, DC_chrominance_value, cbcr_DC_huffman);
    // ��ʼ��ɫ��AC��������
    memset(&cbcr_AC_huffman, 0, sizeof(cbcr_AC_huffman));
    compute_huffman(AC_chrominance_NRcode, AC_chrominance_value, cbcr_AC_huffman);
}
void jpeg::compute_huffman(const char* code, const unsigned char* std, bit* _huffman) {
    unsigned char pos = 0;
    unsigned short code_value = 0;
    // ���ݱ�׼�������������ֳ��ȼ��������Զ����������
    for (int k = 1; k <= 16; k++) {
        for (int j = 1; j <= code[k - 1]; j++) {
            _huffman[std[pos]].value = code_value;
            _huffman[std[pos]].length = k;
            pos++;
            code_value++;
        }
        code_value <<= 1;
    }
}
jpeg::bit jpeg::get(int value) {
    bit ret;
    int v = (value > 0) ? value : -value;
    // ����bit�ĳ���
    int length = 0;
    for (length = 0; v; v >>= 1) {
        length++;
    }
    ret.value = value > 0 ? value : ((1 << length) + value - 1);
    ret.length = length;
    return ret;
};
void jpeg::write_head(FILE* file) {
    //SOI
    write_word(0xFFD8, file);		// marker = 0xFFD8
    //APPO
    write_word(0xFFE0, file);		// marker = 0xFFE0
    write_word(16, file);			// length = 16 for usual JPEG, no thumbnail
    write("JFIF", 5, file);			// 'JFIF\0'
    write_byte(1, file);			// version_hi
    write_byte(1, file);			// version_low
    write_byte(0, file);			// xyunits = 0 no units, normal density
    write_word(1, file);			// xdensity
    write_word(1, file);			// ydensity
    write_byte(0, file);			// thumbWidth
    write_byte(0, file);			// thumbHeight
    //DQT
    write_word(0xFFDB, file);		//marker = 0xFFDB
    write_word(132, file);			//size=132
    write_byte(0, file);			//QTYinfo== 0:  bit 0..3: number of QT = 0 (table for Y) 
    //				bit 4..7: precision of QT
    //				bit 8	: 0
    write(y_table, 64, file);		//YTable
    write_byte(1, file);			//QTCbinfo = 1 (quantization table for Cb,Cr)
    write(cbcr_table, 64, file);	//CbCrTable
    //SOFO
    write_word(0xFFC0, file);			//marker = 0xFFC0
    write_word(17, file);				//length = 17 for a truecolor YCbCr JPG
    write_byte(8, file);				//precision = 8: 8 bits/sample 
    write_word(height & 0xFFFF, file);	//height
    write_word(width & 0xFFFF, file);	//width
    write_byte(3, file);				//nrofcomponents = 3: We encode a truecolor JPG
    write_byte(1, file);				//IdY = 1
    write_byte(0x11, file);				//HVY sampling factors for Y (bit 0-3 vert., 4-7 hor.)(SubSamp 1x1)
    write_byte(0, file);				//QTY  Quantization Table number for Y = 0
    write_byte(2, file);				//IdCb = 2
    write_byte(0x11, file);				//HVCb = 0x11(SubSamp 1x1)
    write_byte(1, file);				//QTCb = 1
    write_byte(3, file);				//IdCr = 3
    write_byte(0x11, file);				//HVCr = 0x11 (SubSamp 1x1)
    write_byte(1, file);				//QTCr Normally equal to QTCb = 1
    //DHT
    write_word(0xFFC4, file);		//marker = 0xFFC4
    write_word(0x01A2, file);		//length = 0x01A2
    write_byte(0, file);			//HTYDCinfo bit 0..3	: number of HT (0..3), for Y =0
    //			bit 4		: type of HT, 0 = DC table,1 = AC table
    //			bit 5..7	: not used, must be 0
    write(DC_luminance_NRcode, sizeof(DC_luminance_NRcode), file);	//DC_L_NRC
    write(DC_luminance_value, sizeof(DC_luminance_value), file);		//DC_L_VALUE
    write_byte(0x10, file);			//HTYACinfo
    write(AC_luminance_NRcode, sizeof(AC_luminance_NRcode), file);
    write(AC_luminance_value, sizeof(AC_luminance_value), file); //we'll use the standard Huffman tables
    write_byte(0x01, file);			//HTCbDCinfo
    write(DC_chrominance_NRcode, sizeof(DC_chrominance_NRcode), file);
    write(DC_chrominance_value, sizeof(DC_chrominance_value), file);
    write_byte(0x11, file);			//HTCbACinfo
    write(AC_chrominance_NRcode, sizeof(AC_chrominance_NRcode), file);
    write(AC_chrominance_value, sizeof(AC_chrominance_value), file);
    //SOS
    write_word(0xFFDA, file);		//marker = 0xFFC4
    write_word(12, file);			//length = 12
    write_byte(3, file);			//nrofcomponents, Should be 3: truecolor JPG
    write_byte(1, file);			//Idy=1
    write_byte(0, file);			//HTY	bits 0..3: AC table (0..3)
    //		bits 4..7: DC table (0..3)
    write_byte(2, file);			//IdCb
    write_byte(0x11, file);			//HTCb
    write_byte(3, file);			//IdCr
    write_byte(0x11, file);			//HTCr
    write_byte(0, file);			//Ss not interesting, they should be 0,63,0
    write_byte(0x3F, file);			//Se
    write_byte(0, file);			//Bf
}
void jpeg::write_string(const bit* bs, int count, int& byte, int& bytepos, FILE* file) {
    // λ�������飬������λ�������ֵ
    unsigned short mask[] = { 1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768 };
    for (int i = 0; i < count; i++) {
        int value = bs[i].value;
        int len = bs[i].length - 1;
        while (len >= 0)
        {
            if ((value & mask[len]) != 0)
            {
                byte = byte | mask[bytepos];
            }
            len--;
            bytepos--;
            if (bytepos < 0) {
                // д����
                write_byte((unsigned char)(byte), file);
                if (byte == 0xFF) {
                    // �����������
                    write_byte((unsigned char)(0x00), file);
                }
                // ���³�ʼ��
                bytepos = 7;
                byte = 0;
            }
        }
    }
}
void jpeg::write_word(unsigned short value, FILE* file) {
    // ��16λ���ݰ��ֽ�˳��д���ļ�
    unsigned short _value = ((value >> 8) & 0xFF) | ((value & 0xFF) << 8);
    write(&_value, 2, file);
}
void jpeg::write_byte(unsigned char value, FILE* file) {
    // д��һ���ֽڵ����ݵ��ļ�
    write(&value, 1, file);
}
void jpeg::write(const void* p, int byteSize, FILE* file) {
    // ��ָ���ֽڴ�С������д���ļ�
    fwrite(p, 1, byteSize, file);
}
int main(int argc, char* argv[]) {
    cout << "ѹ��ͼƬ�����ߣ�����" << endl;
    if (argc != 3) {
        cerr << "���������������" << endl; //������Ĳ����Ƿ���ȷ
        return -1;
    }
    if (!strcmp(argv[1], "-compress")) {
        cout << "����ѹ�������Ե�" << endl;
        PicReader imread;
        BYTE* data = nullptr;
        UINT x, y;
        imread.readPic(argv[2]);
        imread.getData(data, x, y);
        jpeg encoder;
        encoder.change(data, x, y);
        encoder.encode("lena.jpg", 50);
        cout << "ѹ�����!" << endl;
    }
    else if (!strcmp(argv[1], "-read")) {
        PicReader imread;
        BYTE* data = nullptr;
        UINT x, y;
        imread.readPic(argv[2]);
        imread.getData(data, x, y);
        imread.showPic(data, x, y);
    }
    else {
        cout << "δָ֪��" << endl;
        return -1;
    }
    return 0;
}